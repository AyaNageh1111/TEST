#pragma once
#include "book9_3.cpp"
class Account
{

	int id;
	double balance;
	double annualInterestRate;
	int getid();
	int getbalance();
	int getannualInterestRate();
	void setid(int );
	void setbalance(double);
	void setannualInterestRate(double);
	Account();

	double withdraw(double amount) ;

};