#include "book9_3.h"

int Account:: getid()
{
	return id;
}
int Account::getbalance()
{
	return balance;
}
int Account::getannualInterestRate()
{
	return annualInterestRate;
}
void Account::setid(int e)
{
	id = e;
}
void Account::setbalance(double w)
{
	balance = w;
}

void Account::setannualInterestRate(double r)
{
	annualInterestRate = r;
}
Account :: Account()
{
	id = 0;
	balance = 0;
	annualInterestRate = 0;

}
double Account::withdraw(double amount)
{
	balance = balance - amount;
}
