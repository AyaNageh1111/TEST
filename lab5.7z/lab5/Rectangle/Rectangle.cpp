#include "Rectangle.h"
Rectangle::Rectangle()
{
	m_len = 1;
	m_width = 1;

}
double Rectangle:: getArea(double Area)
{
	Area = m_len * m_width;
}
double Rectangle::getPar(double Par)
{
	Par = 2 * m_len *m_width;
}
void Rectangle::setm_len(double e)
{
	m_len = e;
}

void Rectangle::setm_width(double w)
{
	m_width = w;
}