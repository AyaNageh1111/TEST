#pragma once
class Rectangle
{
private:
	double m_len, m_width;
	Rectangle();
	Rectangle(double, double);
	double getArea(double);
	double getPar(double);
	void setm_len(double);
	void setm_width(double);
	



};